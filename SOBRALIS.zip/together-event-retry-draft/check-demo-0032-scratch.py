#!/usr/bin/env python3
"""Read-only dump of the disposable demo; upgrade only a new private scratch DB."""
import os, pathlib, subprocess, uuid
P='/usr/lib/postgresql/17/bin/'
base=pathlib.Path('/home/user/sobralis-private-backups');base.mkdir(mode=0o700,parents=True,exist_ok=True);os.chmod(base,0o700)
admin=pathlib.Path('/tmp/sobralis-cloud-pg/admin.pass').read_text().strip();migrator=pathlib.Path('/tmp/sobralis-cloud-pg/migrate.pass').read_text().strip()
env=os.environ.copy();env.update(PGHOST='127.0.0.1',PGPORT='15432',PGUSER='sobralis_admin',PGPASSWORD=admin)
name='sobralis_event_upgrade_'+uuid.uuid4().hex[:12];path=base/('demo-before-event-0032-'+uuid.uuid4().hex+'.dump')
os.umask(0o077);fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.close(fd)
def run(args,**kw):return subprocess.run(args,env=kw.pop('env',env),check=True,**kw)
def query(db,sql):return run([P+'psql','-X','-v','ON_ERROR_STOP=1','-At','-d',db,'-c',sql],capture_output=True,text=True).stdout.strip()
def digest(db):
 names=query(db,"SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename <> 'schema_migrations' ORDER BY tablename").splitlines();r={}
 for n in names:
  if not n.replace('_','').isalnum():raise RuntimeError('Unexpected table name')
  r[n]=query(db,"SELECT count(*)::text||':'||md5(coalesce(string_agg(to_jsonb(t)::text,E'\\n' ORDER BY to_jsonb(t)::text),'')) FROM public.\""+n+"\" t")
 return r
created=False
try:
 if query('sobralis_demo','SELECT count(*) FROM public.schema_migrations')!='31':raise RuntimeError('Demo is not at expected migration 0031')
 run([P+'pg_dump','-Fc','--file',str(path),'sobralis_demo']);os.chmod(path,0o600)
 run([P+'createdb','-O','sobralis_migrator',name]);created=True
 run([P+'psql','-X','-q','-v','ON_ERROR_STOP=1','-d',name,'-c','REVOKE ALL ON DATABASE "'+name+'" FROM PUBLIC'])
 run([P+'pg_restore','--exit-on-error','-d',name,str(path)])
 original=digest(name);live=digest('sobralis_demo')
 if original!=live:raise RuntimeError('Live demo changed or backup digest differed during comparison; no upgrade performed')
 before=query(name,'SELECT count(*) FROM public.schema_migrations')
 menv=os.environ.copy();menv.update(DB_HOST='127.0.0.1',DB_PORT='15432',DB_NAME=name,DB_USER='sobralis_migrator',DB_PASSWORD=migrator,NODE_ENV='development')
 run(['npm','run','migrate'],cwd='/home/user/together-event-work/backend',env=menv)
 after=digest(name)
 if any(after.get(k)!=v for k,v in original.items()):raise RuntimeError('Existing scratch data differed after migration')
 if query(name,'SELECT count(*) FROM public.schema_migrations')!='32':raise RuntimeError('Scratch migration count unexpected')
 if query('sobralis_demo','SELECT count(*) FROM public.schema_migrations')!='31':raise RuntimeError('Live demo schema changed during check')
 print('Protected dump restored; matched live snapshot; migration 0032 retained data in',len(original),'existing tables; scratch schema',before,'-> 32; live demo remains 31.')
finally:
 if created:run([P+'dropdb','--if-exists',name])
