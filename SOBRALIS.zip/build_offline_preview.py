from pathlib import Path
import base64
root=Path('/home/user/together')
css=(root/'style.css').read_text()
for asset,mime in [('hero-web.webp','image/webp'),('assets/nunito-cyrillic.woff2','font/woff2'),('assets/nunito-latin.woff2','font/woff2')]:
    data=base64.b64encode((root/asset).read_bytes()).decode()
    if asset=='hero-web.webp':
        css=css.replace("url('hero-web.webp')",'var(--preview-hero)')
        css+='\n:root{--preview-hero:url("data:'+mime+';base64,'+data+'")}'
    else: css=css.replace("url('"+asset+"')", "url('data:"+mime+';base64,'+data+"')")
css+='''\n#preview-warning{position:relative;z-index:50;background:#fff4db;color:#775b27;padding:11px 18px;text-align:center;font:700 12px/1.45 system-ui,sans-serif;border-bottom:1px solid #f4dfae}#preview-warning strong{color:#624a21}.sidebar{top:58px}.garland{top:58px}@media(max-width:760px){.sidebar{top:72px}.garland{top:72px}}'''
assert '</style' not in css.lower()
# Always use isolated transient memory: the viewer may prohibit localStorage, and the
# standalone fallback must never read, overwrite, or pretend to synchronize user data.
prelude="""(function(){'use strict';var values=Object.create(null);var store={getItem:function(k){return Object.prototype.hasOwnProperty.call(values,k)?values[k]:null},setItem:function(k,v){values[String(k)]=String(v)},removeItem:function(k){delete values[k]},clear:function(){values=Object.create(null)}};try{Object.defineProperty(window,'localStorage',{configurable:true,value:store})}catch(e){document.getElementById('app').textContent='Не удалось открыть автономный просмотр в этом браузере.';throw e}})();"""
scripts=[prelude]+[(root/name).read_text() for name in ['app.js','enhancements.js','party.js','backup.js']]
assert all('</script' not in x.lower() for x in scripts)
html='''<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data:; font-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'none'"><title>Собрались! — автономный просмотр</title><style>'''+css+'''</style></head><body><div id="preview-warning"><strong>Автономный просмотр.</strong> Он не подключён к серверу и не видит ваши данные. Изменения здесь временные и исчезнут при закрытии.</div><div id="app"></div><div id="modal-root"></div><div id="toast"></div>'''+''.join('<script>'+script+'</script>' for script in scripts)+'</body></html>'
out=Path('/home/user/Собрались — автономный просмотр.html');out.write_text(html)
print('Built self-contained temporary preview:',len(html.encode()),'bytes')
